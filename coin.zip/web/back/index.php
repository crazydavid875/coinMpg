<?php 
    
    include_once('./class/mpg.php');
    include_once('./class/article.php');
    include_once('./class/member.php');
    
    include_once('./class/SQL.php');
    include_once('./route.php');
    

    