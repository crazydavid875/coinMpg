<?php
class Router{
    
    public function __constructor()
    {
        
    }
}

?>